"""Classe"""
from ast import Break
import json
import os
def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):  
        command = 'cls'
    os.system(command)

class classes :
    def __init__(self,codeClasse=1,libelle=""):
        self.codeClasse = codeClasse
        self.libelle = libelle
    
    def afficher(self):
        print("CODE: {}\t LIBELLE: {} ".format(self.codeClasse,self.libelle))
        
    def ajoutClasse(self):
        self.codeClasse = int(input("CODE"))
        self.libelle =input("LIBELLE")
    
    def enregistrer(self):
        """fonction permetant d'enregistrer une classe dans un fichier"""

        classe = {'codeClasse': self.codeClasse,'libelle':self.libelle}
       
        with open(f"classes.txt",'w') as f:
            f.write(json.dumps(classe,indent=4))
            
    def lire(self): 
        """ la liste des classes dans un fichier"""
        with open(f"classes.txt" , 'r') as f:
            data = json.loads(f.read())
        
        self.codeClasse = data['codeClasse']
        self.libelle = data['libelle']
    
def main():
    def test_classe():
        clearConsole()
        cl = classes()
        print("CLASSES")
        print("1.ENREGISTRER UN CLASSE ")
        print("2.AFFICHER LA LISTE DE CLASSE")
        print("3.QUITTER ")
        choix = int(input("FAITE VOTRE CHOIX :"))
        if choix==1:
            clearConsole()
            print("ENREGISTRER UN Classe")
            cl.ajoutClasse()
            cl.enregistrer()
            cl.afficher()
        elif choix==2:
            cl.lire()
            cl.afficher()
        elif choix == 3:
            Break 
        else:
            print("ERREUR DE CHOIX")
    test_classe()
if __name__ =="__main__":
    main()