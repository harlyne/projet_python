"""professeur"""
from ast import Break
import json
import os
def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):  
        command = 'cls'
    os.system(command)

class professeurs :
    def __init__(self,matricule=1,nom="",prenom="",matiereEnseigner=""):
        self.matricule = matricule
        self.nom = nom
        self.prenom = prenom
        self.matiereEnseigner = matiereEnseigner
    
    def afficher(self):
        print("CODE: {}\t nom: {} \t prenom: {}\t matiereEnseigner: {} ".format(self.matricule,self.nom,self.prenom,self.matiereEnseigner))
        
    def addProfessor(self):
        self.matricule = int(input("Matricule : "))
        self.nom =input("Nom : ")
        self.prenom =input("Prenom : ")
        self.matiereEnseigner =input("Matiere : ")
    
    def save(self):
        """fonction permetant d'enregistrer une professeur dans un fichier"""

        professeur = {'matricule': self.matricule,'nom':self.nom,'prenom':self.prenom, 'matiereEnseigner':self.matiereEnseigner}
       
        with open(f"professeurs.txt",'w') as f:
            f.write(json.dumps(professeur,indent=4))
            
    def lire(self): 
        """ la liste des professeurs dans un fichier"""
        with open(f"professeurs.txt" , 'r') as f:
            data = json.loads(f.read())
        
        self.matricule = data['matricule']
        self.nom = data['nom']
        self.prenom = data['prenom']
        self.matiereEnseigner = data['matiereEnseigner']
    
def main():
    def test_prof():
        clearConsole()
        et = professeurs()
        print("PROFESSEURS")
        print("1.ENREGISTRER UN PROFESSEUR ")
        print("2.AFFICHER LA LISTE DES PROFESSEURS")
        print("3.QUITTER ")
        choix = int(input("FAITE VOTRE CHOIX :"))
        if choix==1:
            clearConsole()
            print("ENREGISTRER UN PROFESSEUR")
            et.addProfessor()
            et.save()
            et.afficher()
        elif choix==2:
            et.lire()
            et.afficher()
        elif choix == 3:
            Break
        else:
            print("ERREUR DE CHOIX")
    test_prof()
if __name__ =="__main__":
    main()