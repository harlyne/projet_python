"""matiere"""
from ast import Break
import json
import os
def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):  
        command = 'cls'
    os.system(command)

class matieres :
    def __init__(self,codeMatiere=1,libelle=""):
        self.codeMatiere = codeMatiere
        self.libelle = libelle
    
    def afficher(self):
        print("CODE : {}\t LIBELLE: {} ".format(self.codeMatiere,self.libelle))
        
    def addMatiere(self):
        self.codeMatiere = int(input("CODE"))
        self.libelle =input("LIBELLE")
    
    def save(self):
        """fonction permetant d'enregistrer une matiere dans un fichier"""

        matiere = {'codeMatiere': self.codeMatiere,'libelle':self.libelle}
       
        with open(f"matieres.txt",'w') as f:
            f.write(json.dumps(matiere,indent=4))
            
    def lire(self): 
        """ la liste des matieres dans un fichier"""
        with open(f"matieres.txt" , 'r') as f:
            data = json.loads(f.read())
        
        self.codeMatiere = data['codeMatiere']
        self.libelle = data['libelle']
    
def main():
    def test_mat():
        clearConsole()
        ma = matieres()
        print("MATIERES")
        print("1.ENREGISTRER UN MATIERE ")
        print("2.AFFICHER LA LISTE DE MATIERE")
        print("3.QUITTER ")
        choix = int(input("FAITE VOTRE CHOIX :"))
        if choix==1:
            clearConsole()
            print("ENREGISTRER UN matiere")
            ma.addMatiere()
            ma.save()
            ma.afficher()
        elif choix==2:
            ma.lire()
            ma.afficher()
        elif choix == 3:
            Break 
        else:
            print("ERREUR DE CHOIX")
    test_mat()

if __name__ =="__main__":
    main()