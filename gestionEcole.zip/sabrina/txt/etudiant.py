"""ETUDIANT"""
from ast import Break
import json
import os
def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):  
        command = 'cls'
    os.system(command)

class etudiants :
    def __init__(self,matricule=1,nom="",prenom="",dateNaissance=""):
        self.matricule = matricule
        self.nom = nom
        self.prenom = prenom
        self.dateNaissance = dateNaissance
    
    def afficher(self):
        print("CODE: {}\t nom: {} \t prenom: {}\t dateNaissance: {} ".format(self.matricule,self.nom,self.prenom,self.dateNaissance))
        
    def ajoutEtudiant(self):
        self.matricule = int(input("CODE"))
        self.nom =input("Nom")
        self.prenom =input("Prenom")
        self.dateNaissance =input("Date de naissance(AAAA-MM-JJ) : ")
    
    def enregistrer(self):
        """fonction permetant d'enregistrer une Etudiant dans un fichier"""

        etudiant = {'matricule': self.matricule,'nom':self.nom,'prenom':self.prenom, 'dateNaissance':self.dateNaissance}
       
        with open(f"etudiants.txt",'w') as f:
            f.write(json.dumps(etudiant,indent=4))
            
    def lire(self): 
        """ la liste des Etudiants dans un fichier"""
        with open(f"etudiants.txt" , 'r') as f:
            data = json.loads(f.read())
        
        self.matricule = data['matricule']
        self.nom = data['nom']
        self.prenom = data['prenom']
        self.dateNaissance = data['dateNaissance']
    
def main():
    def test():
        clearConsole()
        et = etudiants()
        print("ETUDIANTS")
        print("1.ENREGISTRER UN ETUDIANT ")
        print("2.AFFICHER LA LISTE DES ETUDIANTS")
        print("3.QUITTER ")
        choix = int(input("FAITE VOTRE CHOIX :"))
        if choix==1:
            clearConsole()
            print("ENREGISTRER UN ETUDIANT")
            et.ajoutEtudiant()
            et.enregistrer()
            et.afficher()
        elif choix==2:
            et.lire()
            et.afficher()
        elif choix == 3:
            Break
        else:
            print("ERREUR DE CHOIX")
    test()
if __name__ =="__main__":
    main()