"""Programme principal"""
from ast import Break
import os
from matiere import matieres
from etudiant import etudiants
from professeur import professeurs
from classe import classes
def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):  
        command = 'cls'
    os.system(command)
def test_et():
        clearConsole()
        et = etudiants()
        print("ETUDIANTS")
        print("1.ENREGISTRER UN ETUDIANT ")
        print("2.AFFICHER LA LISTE DES ETUDIANTS")
        print("3.QUITTER ")
        choix = int(input("FAITE VOTRE CHOIX :"))
        if choix==1:
            clearConsole()
            print("ENREGISTRER UN ETUDIANT")
            et.ajoutEtudiant()
            et.enregistrer()
            et.afficher()
        elif choix==2:
            et.lire()
            et.afficher()
        elif choix == 3:
            Break
        else:
            print("ERREUR DE CHOIX")
def test_prof():
        clearConsole()
        et = professeurs()
        print("PROFESSEURS")
        print("1.ENREGISTRER UN PROFESSEUR ")
        print("2.AFFICHER LA LISTE DES PROFESSEURS")
        print("3.QUITTER ")
        choix = int(input("FAITE VOTRE CHOIX :"))
        if choix==1:
            clearConsole()
            print("ENREGISTRER UN PROFESSEUR")
            et.addProfessor()
            et.save()
            et.afficher()
        elif choix==2:
            et.lire()
            et.afficher()
        elif choix == 3:
            Break
        else:
            print("ERREUR DE CHOIX")

def test_mat():
        clearConsole()
        ma = matieres()
        print("MATIERES")
        print("1.ENREGISTRER UN MATIERE ")
        print("2.AFFICHER LA LISTE DE MATIERE")
        print("3.QUITTER ")
        choix = int(input("FAITE VOTRE CHOIX :"))
        if choix==1:
            clearConsole()
            print("ENREGISTRER UN matiere")
            ma.addMatiere()
            ma.save()
            ma.afficher()
        elif choix==2:
            ma.lire()
            ma.afficher()
        elif choix == 3:
            Break 
        else:
            print("ERREUR DE CHOIX")

def test_classe():
        clearConsole()
        cl = classes()
        print("CLASSES")
        print("1.ENREGISTRER UN CLASSE ")
        print("2.AFFICHER LA LISTE DE CLASSE")
        print("3.QUITTER ")
        choix = int(input("FAITE VOTRE CHOIX :"))
        if choix==1:
            clearConsole()
            print("ENREGISTRER UN Classe")
            cl.ajoutClasse()
            cl.enregistrer()
            cl.afficher()
        elif choix==2:
            cl.lire()
            cl.afficher()
        elif choix == 3:
            Break 
        else:
            print("ERREUR DE CHOIX")
            
            
            
def principal():
    """fonction appellant tous les modules"""
    print("GESTION ETABLISSEMENT SCOLAIRE : ")
    print("1.GESTION DE ETUDIANT ")
    print("2.GESTION DE PROFESSEUR ")
    print("3.GESTION DE MATIERE")
    print("4.GESTION DE CLASSE")
    choix= int(input("CHOIX"))
    if choix ==  1:
        test_et()
    elif choix == 2 :
        test_prof()
    elif choix == 3 :
        test_mat()
    elif choix == 4 :
        test_classe()
    else :
        print("Erreur de choix")
        
        


def main():
    principal()

if __name__ == "__main__":
    main()